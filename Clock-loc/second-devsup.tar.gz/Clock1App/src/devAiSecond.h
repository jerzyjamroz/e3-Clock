/**
   devAiSecond.h
   kazuro furukawa, dec.14.2006.
**/

/*
 @(#)devAiSecond v0.1 support for second, k.furukawa, dec.2006
*/

#include <time.h>
